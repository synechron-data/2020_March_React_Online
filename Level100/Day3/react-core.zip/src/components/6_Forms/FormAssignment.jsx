import React, { Component } from 'react';
import DataTable from '../common/DataTable';
import TextInput from '../common/TextInput';

class FormComponent extends Component {
    constructor(props) {
        super(props);
        this.state = { id: 0, name: "", designation: "", salary: "" };
        this.save = this.save.bind(this);
        this.reset = this.reset.bind(this);
        this.updateState = this.updateState.bind(this);
    }

    updateState(e) {
        const field = e.target.id;
        var newState = { ...this.state };
        if ((field == "id") && e.target.value)
            newState[field] = parseInt(e.target.value);
        else
            newState[field] = e.target.value;
        this.setState(newState);
    }

    save(e) {
        e.preventDefault();
        this.props.onSave(this.state);
    }

    reset(e) {
        this.setState({ id: 0, name: "", designation: "", salary: "" });
    }

    render() {
        return (
            <div className="row">
                <div className="col-sm-6 offset-sm-3">
                    <form className="form-horizontal" autoComplete="off" onSubmit={this.save}>
                        <fieldset>
                            <legend className="text-center text-secondary text-uppercase font-weight-bold">Add Employee Information</legend>
                            <hr className="mt-0" />
                            <TextInput label={"Id"} name={"id"} value={this.state.id} onChange={this.updateState} />
                            <TextInput label={"Name"} name={"name"} value={this.state.name} onChange={this.updateState} />
                            <TextInput label={"Designation"} name={"designation"} value={this.state.designation} onChange={this.updateState} />
                            <TextInput label={"Salary"} name={"salary"} value={this.state.salary} onChange={this.updateState} />

                            <div className="row mt-3">
                                <div className="col">
                                    <button type="submit" className="btn btn-success btn-block">Save</button>
                                </div>
                                <div className="col">
                                    <button type="reset" className="btn btn-primary btn-block" onClick={this.reset}>Reset</button>
                                </div>
                            </div>
                        </fieldset>
                    </form>
                </div>
            </div>
        );
    }
}

class FormAssignment extends Component {
    constructor(props) {
        super(props);
        this.state = {
            employees: [
            ]
        };
        this.saveEmployee = this.saveEmployee.bind(this);
        this.removeEmployee = this.removeEmployee.bind(this);
    }

    saveEmployee(employee, e) {
        this.setState({
            employees: [...this.state.employees, { ...employee }]
        });
    }

    removeEmployee(id, e) {
        this.setState({
            employees: [...this.state.employees.filter((item) => {
                return item.id !== id;
            })]
        });
    }

    render() {
        return (
            <div>
                <FormComponent onSave={this.saveEmployee} />
                <DataTable items={this.state.employees} onDelete={this.removeEmployee}>
                    <h5 className="text-primary text-uppercase font-weight-bold">Employees Table</h5>
                </DataTable>
            </div>
        );
    }
}

export default FormAssignment;