import React, { Component } from 'react';

class ParentComponent extends Component {
    constructor(props) {
        super(props);
        this.state = { data: 0, flag: true };
        console.log("Parent - Ctor");
    }

    handleChange(e) {
        this.setState({ data: this.state.data + 1 });
    }

    handleLoad(e) {
        this.setState({ flag: !this.state.flag });
    }

    render() {
        console.log("Parent - Render");

        var child = this.state.flag ? null : (
            <Child value={this.state.data} />
        );

        return (
            <div>
                <button onClick={this.handleChange.bind(this)}>Change</button>
                <button onClick={this.handleLoad.bind(this)}>Load/Unload</button>
                <hr />
                {child}
            </div>
        );
    }
}

class Child extends Component {
    constructor(props) {
        super(props);
        this.state = { childState: 1 };
        console.log("Child - Ctor");
    }

    componentWillMount() {
        console.log("Child - componentWillMount");
    }

    componentDidMount() {
        console.log("Child - componentDidMount");
    }

    handleClick(e) {
        this.setState({ childState: this.state.childState + 1 });
    }

    updateClick(e) {
        this.forceUpdate();
    }

    render() {
        console.log("Child - Render");

        return (
            <div>
                <h2>Child Component</h2>
                <h3>Value: {this.props.value}</h3>
                <h3>Child Value: {this.state.childState}</h3>
                <button onClick={this.handleClick.bind(this)}>Change Child</button>
                <button onClick={this.updateClick.bind(this)}>Force Update</button>
            </div>
        );
    }

    componentWillReceiveProps(newProps) {
        console.log("Child - componentWillReceiveProps");
    }

    shouldComponentUpdate(newProps, newState) {
        console.log("Child - shouldComponentUpdate");
        return false;
    }

    componentWillUpdate() {
        console.log("Child - componentWillUpdate");
    }

    componentDidUpdate() {
        console.log("Child - componentDidUpdate");
    }

    componentWillUnmount() {
        console.log("Child - componentWillUnmount");
    }
}


export default ParentComponent;