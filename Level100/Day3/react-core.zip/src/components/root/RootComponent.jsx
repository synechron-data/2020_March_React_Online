/* eslint-disable */
import React, { Component } from 'react';

import DataFlowAssignment from '../1_data-flow/DataFlowAssignment';
import ControlledAndUncontrolled from '../2_controlledvsuncontrolled/ControlledAndUncontrolled';
import CalculatorAssignment from '../3_calculator/CalculatorAssignment';
import ListRoot from '../4_List/ListComponent';
import PropTypeRoot from '../5_PropTypes/proptypesdemo';
import FormAssignment from '../6_Forms/FormAssignment';
import ErrorHandler from '../common/ErrorHandler';
import ParentComponent from '../7_LifecycleDemo/DemoComponent';

class RootComponent extends Component {
    test() {
        alert("Test Method Called....");
    }

    render() {
        return (
            <div className="container">
                <ErrorHandler>
                    {/* <DataFlowAssignment /> */}
                    {/* <ControlledAndUncontrolled /> */}
                    {/* <CalculatorAssignment /> */}
                    {/* <ListRoot /> */}
                    {/* <PropTypeRoot /> */}
                    <FormAssignment />
                    {/* <ParentComponent /> */}
                </ErrorHandler>
            </div>
        );
    }
}

export default RootComponent;