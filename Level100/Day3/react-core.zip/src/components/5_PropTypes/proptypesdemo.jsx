import React, { Component } from 'react';
import PropTypes from 'prop-types';

class PropTypeComponent extends Component {
    render() {
        var ename = this.props.name.toUpperCase();
        return (
            <div>
                <h3 className="text-info">Hello, {ename}</h3>
                <h3 className="text-info">Age, {this.props.age}</h3>
            </div>
        );
    }

    static get propTypes() {
        return {
            name: PropTypes.string.isRequired,
            // age: PropTypes.number.isRequired
            age: function (props, propName, componentName) {
                if (!props[propName])
                    return new Error(`${componentName} --- ${propName}, is required...`);
            }
        };
    }
}

class PropTypeRoot extends Component {
    render() {
        return (
            <div>
                <PropTypeComponent name={"manish"} />
            </div>
        );
    }
}

export default PropTypeRoot;