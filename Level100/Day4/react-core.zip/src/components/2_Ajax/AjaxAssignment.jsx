import React, { Component } from 'react';
import TextInput from '../common/TextInput';
import awsClient from '../../services/aws.service';

class AjaxAssignment extends Component {
    constructor(props) {
        super(props);
        this.state = { data: 0, result: "", message: "Click the button to get result" };
        this.handleClick = this.handleClick.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.reset = this.reset.bind(this);
    }

    handleClick(e) {
        awsClient.getResult(this.state.data).then((data) => {
            this.setState({ message: "", result: data });
        }).catch((eMsg) => {
            this.setState({ result: "", message: eMsg });
        });
    }

    handleChange(e) {
        const field = e.target.id;
        var obj = { ...this.state };
        obj[field] = e.target.value;
        this.setState({ ...obj });
    }

    reset(e){
        this.setState({ data: 0, result: "", message: "Click the button to get result" });
    }

    render() {
        return (
            <React.Fragment>
                <div className="row">
                    <h4 className="text-warning text-uppercase font-weight-bold">{this.state.message}</h4>
                </div>
                <div>
                    <TextInput label={"Enter a number"} placeholder={"Enter a number"} name={"data"} value={this.state.data} onChange={this.handleChange} />
                    <br />
                    <button className="btn btn-primary" onClick={this.handleClick}>Get Response</button>
                    <button className="btn btn-info" onClick={this.reset}>Reset</button>
                    <h2>Result: {this.state.result}</h2>
                </div>
            </React.Fragment>
        );
    }
}

export default AjaxAssignment;