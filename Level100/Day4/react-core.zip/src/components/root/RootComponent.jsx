/* eslint-disable */
import React, { Component } from 'react';

import FormAssignment from '../1_Forms/FormAssignment';
import ErrorHandler from '../common/ErrorHandler';
import AjaxComponent from '../2_Ajax/AjaxComponent';
import AjaxAssignment from '../2_Ajax/AjaxAssignment';
import DemoComponent from '../3_XssDemo/DemoComponent';

class RootComponent extends Component {
    render() {
        return (
            <div className="container">
                <ErrorHandler>
                    {/* <FormAssignment /> */}
                    {/* <AjaxComponent /> */}
                    {/* <AjaxAssignment /> */}
                    <DemoComponent />
                </ErrorHandler>
            </div>
        );
    }
}

export default RootComponent;