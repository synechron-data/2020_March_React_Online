var employees = [
    { id: 1, name: "Manish", city: "Pune" },
    { id: 2, name: "Ram", city: "Mumbai" },
    { id: 3, name: "Rohit", city: "Pune" }
];

// var pune_emps = [];

// function filterLogic(emp) {
//     return emp.city === "Pune";
// }

// for (let i = 0; i < employees.length; i++) {
//     if (filterLogic(employees[i]))
//         pune_emps.push(employees[i]);
// }

// console.log(pune_emps);

// // ----------------------------------------
// function filterLogic(emp) {
//     return emp.city === "Pune";
// }

// var pune_emps = employees.filter(filterLogic);
// console.log(pune_emps);

// // ----------------------------------------
// var pune_emps = employees.filter(function (emp) {
//     return emp.city === "Pune";
// });
// console.log(pune_emps);

// ----------------------------------------
// var pune_emps = employees.filter((emp) => {
//     return emp.city === "Pune";
// });
// console.log(pune_emps);

// var pune_emps = employees.filter((emp) => emp.city === "Pune");
// console.log(pune_emps);

// var p = {
//     test: function () {
//         console.log(this);
//     }
// }

var p = {
    test: () => {
        console.log(this);
    }
}

// p.test();
// setTimeout(p.test, 2000);