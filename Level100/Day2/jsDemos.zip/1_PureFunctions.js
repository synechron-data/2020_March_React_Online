// var x = 10;

// function test(p) {
//     p = "Changed";
//     console.log("Inside, p is: ", p);
// }

// console.log("Before, x is: ", x);
// test(x);
// console.log("After, x is: ", x);

// var x = 10;
// var y = x;

// console.log("Before, x is: ", x);
// y = 20;
// console.log("After, x is: ", x);

// var x = { n: 10 };
// // Object.freeze(x);
// var y = x;

// console.log("Before, x is: ", x);
// y.n = 20;
// console.log("After, x is: ", x);

var arr = [10, 20, 30, 40];

// Impure
// function insert(n, arr){
//     arr[arr.length] = n
// }

// Pure Fn
function insert(n, arr){
    var nArr = [...arr];
    nArr[arr.length] = n;
    return nArr;
}

var nArr = insert(50, arr);

console.log(arr);
console.log(nArr);
