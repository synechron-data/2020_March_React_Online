class Counter {
    constructor() {
        this.count = 0;
    }

    incCount() {
        console.log(this);
        this.count += 1;
    }
}

var c = new Counter();
// c.incCount();
// console.log(c.count);
// c.incCount();
// console.log(c.count);
// c.incCount();
// console.log(c.count);

setInterval(c.incCount.bind(c), 2000);

setInterval(function () {
    console.log(c.count);
}, 2000);