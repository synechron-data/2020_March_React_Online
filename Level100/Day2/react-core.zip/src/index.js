// import React from 'react';
// import ReactDOM from 'react-dom';
// import './index.css';

// import HelloComponent from './components/1_hello/HelloComponent';

// ReactDOM.render(
//   <React.StrictMode>
//     <HelloComponent />
//   </React.StrictMode>,
//   document.getElementById('root')
// );

// // -------------------------------------- Multiple Components

// import React from 'react';
// import ReactDOM from 'react-dom';
// import './index.css';

// import ComponentOne from './components/2_multi-components/ComponentOne';
// import ComponentTwo from './components/2_multi-components/ComponentTwo';

// // ReactDOM.render(<ComponentOne />, document.getElementById('root1'));
// // ReactDOM.render(<ComponentTwo />, document.getElementById('root2'));

// // ReactDOM.render([<ComponentOne />, <ComponentTwo />], document.getElementById('root'));

// // ReactDOM.render(<React.Fragment>
// //   <ComponentOne />
// //   <ComponentTwo />
// // </React.Fragment>, document.getElementById('root'));

// ReactDOM.render(<React.StrictMode>
//   <ComponentOne />
//   <ComponentTwo />
// </React.StrictMode>, document.getElementById('root'));

// -------------------------------------- Multiple Components (Nested)
// import React from 'react';
// import ReactDOM from 'react-dom';
// import './index.css';
// import RootComponent from './components/root/RootComponent';

// ReactDOM.render(<React.StrictMode>
//   <RootComponent />
// </React.StrictMode>, document.getElementById('root'));

// // -------------------------------------- Using Bootstrap 3
// // npm install --save bootstrap@3 jquery

// import 'bootstrap/dist/css/bootstrap.css'
// import 'bootstrap/dist/css/bootstrap-theme.css'

// import React from 'react';
// import ReactDOM from 'react-dom';
// import './index.css';
// import RootComponent from './components/root/RootComponent';

// const jQuery = require('jquery');
// window.jQuery = jQuery;

// require('bootstrap');

// ReactDOM.render(<React.StrictMode>
//   <RootComponent />
// </React.StrictMode>, document.getElementById('root'));

// -------------------------------------- Using Bootstrap 4
// npm uninstall --save bootstrap jquery (To Uninstall Bootstrap 3)
// npm install --save bootstrap popper.js jquery
// npm install --save-dev node-sass

import 'bootstrap/scss/bootstrap.scss';

import React from 'react';
import ReactDOM from 'react-dom';
import 'bootstrap';

import './index.css';
import RootComponent from './components/root/RootComponent';

// ReactDOM.render(<React.StrictMode>
//   <RootComponent />
// </React.StrictMode>, document.getElementById('root'));

ReactDOM.render(<RootComponent />, document.getElementById('root'));