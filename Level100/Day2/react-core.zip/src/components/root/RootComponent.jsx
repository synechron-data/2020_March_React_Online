/* eslint-disable */
import React, { Component } from 'react';
import ComponentWithBehavior from '../9_behavior/ComponentWithBehavior';
import EventObjectComponent from '../10_event/EventObjectComponent';
import CounterAssignment from '../11_counter/CounterAssignment';
import DataFlowAssignment from '../12_data-flow/DataFlowAssignment';

// import ComponentOne from '../2_multi-components/ComponentOne';
// import ComponentTwo from '../2_multi-components/ComponentTwo';

// import ComponentOne from '../3_components-with-css/ComponentOne';
// import ComponentTwo from '../3_components-with-css/ComponentTwo';

// import ComponentOne from '../4_external-css/comp-one/ComponentOne';
// import ComponentTwo from '../4_external-css/comp-two/ComponentTwo';

// import ComponentOne from '../5_css-modules/comp-one/ComponentOne';
// import ComponentTwo from '../5_css-modules/comp-two/ComponentTwo';
// import ComponentWithState from '../6_state/ComponentWithState';
// import ComponentWithProps from '../7_props/ComponentWithProps';
// import ClassVsFunctionalComponent from '../8_compare/ClassVsFunctional';

class RootComponent extends Component {
    test() {
        alert("Test Method Called....");
    }

    render() {
        return (
            <div className="container">
                {/* <ComponentOne />
                <ComponentTwo /> */}

                {/* <ComponentWithState /> */}
                {/* <ComponentWithProps name={"Synechron"} address={{ city: "Pune", state: "MH" }} display={this.test} /> */}
                {/* <ClassVsFunctionalComponent /> */}
                {/* <ComponentWithBehavior /> */}
                {/* <EventObjectComponent /> */}
                {/* <CounterAssignment /> */}
                <DataFlowAssignment />
            </div>
        );
    }
}

export default RootComponent;