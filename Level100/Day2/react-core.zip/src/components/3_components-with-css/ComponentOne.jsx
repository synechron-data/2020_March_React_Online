import React, { Component } from 'react';

const card1 = {
    margin: "1em",
    paddingLeft: 0,
    border: "2px solid blue"
};

class ComponentOne extends Component {
    render() {
        return (
            <h1 style={card1} className="text-info">Hello from Component One</h1>
        );
    }
}

export default ComponentOne;