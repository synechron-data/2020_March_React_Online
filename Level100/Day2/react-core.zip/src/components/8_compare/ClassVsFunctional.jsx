/* eslint-disable */
import React, { Component } from './node_modules/react';

class ComponentOne extends Component {
    render() {
        console.log(this.state);
        console.log(this.props);

        return (
            <div>
                <h1 className="text-info">Using Class Syntax</h1>
            </div>
        );
    }
}

// Presentational (Stateless Components)
const ComponentTwo = () => {
    console.log("ComponentTwo", this);
    // console.log(this.state);
    // console.log(this.props);
    return (
        <div>
            <h1 className="text-info">Using Function Syntax</h1>
        </div>
    );
}

const ComponentThree = (props) => {
    console.log(props);
    return (
        <div>
            <h1 className="text-info">Using Function Syntax</h1>
        </div>
    );
}

const ComponentFour = ({ id, name }) => {
    console.log(id);
    console.log(name);
    return (
        <div>
            <h1 className="text-info">Using Function Syntax</h1>
        </div>
    );
}

const ComponentFive = ({ id, name, ...args }) => {
    console.log(id);
    console.log(name);
    console.log(args);
    return (
        <div>
            <h1 className="text-info">Using Function Syntax</h1>
        </div>
    );
}

class ClassVsFunctionalComponent extends Component {
    render() {
        return (
            <div>
                {/* <ComponentOne /> */}
                {/* <ComponentTwo /> */}
                {/* <ComponentThree id={1} name={"Manish"} city={"Pune"} state={"MH"} /> */}
                {/* <ComponentFour id={1} name={"Manish"} city={"Pune"} state={"MH"} /> */}
                <ComponentFive id={1} name={"Manish"} city={"Pune"} state={"MH"} />
            </div>
        );
    }
}

export default ClassVsFunctionalComponent;