import React, { Component } from 'react';

const Result = (props) => (
    <h2 className="text-info">Result: </h2>
);

const Button = (props) => (
    <button className="btn btn-info">
        Add 
    </button>
);

class DataFlowAssignment extends Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <div>
                <Result />
                <Button />
                <Button />
                <Button />
                <Button />
            </div>
        );
    }
}

export default DataFlowAssignment;