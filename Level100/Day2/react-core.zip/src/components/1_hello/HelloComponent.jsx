// import React from 'react';

// // class HelloComponent extends React.Component {
// //     render() {
// //         // You can return Primitive Types
// //         // return "Hello";
// //         // return 10;
// //         // return true;
// //         // return Symbol("Hello");

// //         // You cannot return Complex (Object) Type
// //         return { id: 1 };
// //     }
// // }

// class HelloComponent extends React.Component {
//     render() {
//         // Will always return a JSX Element
//         // return (
//         //     <div>
//         //         <h1 className="card">Hello World!</h1>
//         //         <h1 className="card">Hello World Again!</h1>
//         //     </div>
//         // );

//         return (
//             <React.Fragment>
//                 <h1 className="card">Hello World!</h1>
//                 <h1 className="card">Hello World Again!</h1>
//             </React.Fragment>
//         );
//     }
// }

// export default HelloComponent;

// -----------------------------------------------------------

// import React, { Component, Fragment } from 'react';

// class HelloComponent extends Component {
//     render() {
//         return (
//             <Fragment>
//                 <h1 className="card">Hello World!</h1>
//                 <h1 className="card">Hello World Again!</h1>
//             </Fragment>
//         );
//     }
// }

// export default HelloComponent;

// // ---------------------------------------------------------- Functional Components

// import React from 'react';

// // function HelloComponent() {
// //     return (
// //         <React.Fragment>
// //             <h1 className="card">Using Functional Components</h1>
// //             <h1 className="card">Hello World!</h1>
// //             <h1 className="card">Hello World Again!</h1>
// //         </React.Fragment>
// //     );
// // }

// const HelloComponent = function () {
//     return (
//         <React.Fragment>
//             <h1 className="card">Using Functional Components</h1>
//             <h1 className="card">Hello World!</h1>
//             <h1 className="card">Hello World Again!</h1>
//         </React.Fragment>
//     );
// }

// export default HelloComponent;

// ---------------------------------------------------------- Functional Components (Arrow)

import React from 'react';

// const HelloComponent = () => {
//     return (
//         <React.Fragment>
//             <h1 className="card">Functional Components (Arrow Syntax)</h1>
//             <h1 className="card">Hello World!</h1>
//             <h1 className="card">Hello World Again!</h1>
//         </React.Fragment>
//     );
// }

const HelloComponent = () => (
    <React.Fragment>
        <h1 className="card">Functional Components (Single Line Arrow Syntax)</h1>
        <h1 className="card">Hello World!</h1>
        <h1 className="card">Hello World Again!</h1>
    </React.Fragment>
);

export default HelloComponent;