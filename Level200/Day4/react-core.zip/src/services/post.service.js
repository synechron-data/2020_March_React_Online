const url = "https://jsonplaceholder.typicode.com/posts";

const apiClient = {
    getAllPosts: function () {
        var promise = new Promise((resolve, reject) => {
            fetch(url).then((response) => {
                response.json().then((data) => {
                    resolve(data);
                }).catch((err) => {
                    reject("Parsing Error...");
                });
            }).catch((err) => {
                reject("Communication Error...");
            });
        });

        return promise;
    }
};

export default apiClient;