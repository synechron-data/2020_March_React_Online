const url = "https://wgr65gw7k8.execute-api.us-east-2.amazonaws.com/prod/my-resource?myParam=";

const awsClient = {
    getResult: function (n) {
        var promise = new Promise((resolve, reject) => {
            const fUrl = `${url}${n}`;
            fetch(fUrl).then((response) => {
                response.json().then((data) => {
                    resolve(data.body);
                }).catch((err) => {
                    reject("Parsing Error...");
                });
            }).catch((err) => {
                reject("Communication Error...");
            });
        });

        return promise;
    }
};

export default awsClient;