import React, { Component } from 'react';
import DataTable from '../common/DataTable';
import apiClient from '../../services/post.service';

class ChildTwo extends Component {
    render() {
        return (
            <div>
                <h3 className="text-info">Child Two</h3>
                <DataTable items={this.props.data}>
                    <h4 className="text-warning text-uppercase font-weight-bold">Posts Table</h4>
                </DataTable>
            </div>
        );
    }
}

class ChildOne extends Component {
    render() {
        return (
            <div>
                <h3 className="text-info">Child One</h3>
                <ChildTwo data={this.props.data}/>
            </div>
        );
    }
}

class AjaxComponent extends Component {
    constructor(props) {
        super(props);
        this.state = { posts: [], message: "Loading Data, please wait...." };
    }

    render() {
        return (
            <React.Fragment>
                <h2 className="text-info">Parent Component</h2>
                <div className="row">
                    <h4 className="text-warning text-uppercase font-weight-bold">{this.state.message}</h4>
                </div>
                <ChildOne data={this.state.posts}/>
            </React.Fragment>
        );
    }

    componentDidMount() {
        apiClient.getAllPosts().then((data) => {
            this.setState({ message: "", posts: data });
        }).catch((eMsg) => {
            this.setState({ message: eMsg, posts: [] });
        });
    }
}

export default AjaxComponent;