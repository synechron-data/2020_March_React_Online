/* eslint-disable */
import React, { Component } from 'react';

import ErrorHandler from '../common/ErrorHandler';
import AjaxComponent from '../1_PropDrilling/AjaxComponent';
import ContextAPIDemo from '../2_ContextAPI/ContextAPIDemo';

class RootComponent extends Component {
    render() {
        return (
            <div className="container">
                <ErrorHandler>
                    {/* <AjaxComponent /> */}
                    <ContextAPIDemo />
                </ErrorHandler>
            </div>
        );
    }
}

export default RootComponent;