import * as actionTypes from '../actions/actionTypes';
import initialState from './initialState';

// Reducers specify how the application's state changes in response to actions dispatched (sent) to the store.
// Remember that actions only describe what happened, but don't describe how the application's state changes.

const counterReducer = (state = initialState.count, action) => {
    let newState;

    switch (action.type) {
        case actionTypes.INCREMENT_COUNTER:
            newState = state + action.payload;
            return newState;
        case actionTypes.DECREMENT_COUNTER:
            newState = state - action.payload;
            return newState;
        case actionTypes.MULTIPLY_COUNTER:
            newState = state * action.payload;
            return newState;
        case actionTypes.DIVIDE_COUNTER:
            newState = state / action.payload;
            return newState;
        default:
            return state;
    }
}

export default counterReducer;