import * as actionTypes from '../actions/actionTypes';
import initialState from './initialState';

const productReducer = (state = initialState.productsData, action) => {
    switch (action.type) {
        case actionTypes.LOAD_PRODUCTS_REQUESTED:
            return {
                products: [],
                status: action.payload.message,
                flag: action.payload.flag
            };
        case actionTypes.LOAD_PRODUCTS_SUCCESS:
            return {
                products: [...action.payload.data],
                status: action.payload.message,
                flag: action.payload.flag
            };
        case actionTypes.LOAD_PRODUCTS_FAILED:
            return {
                products: [...state.products],
                status: action.payload.message,
                flag: action.payload.flag
            };
        default:
            return state;
    }
}

export default productReducer;