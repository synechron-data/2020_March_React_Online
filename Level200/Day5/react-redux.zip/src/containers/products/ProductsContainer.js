import React, { Component } from 'react';
import { connect } from 'react-redux';

import * as productActions from '../../actions/productActions';

class ProductsContainer extends Component {
    render() {
        return (
            <div>

            </div>
        );
    }

    componentDidMount(){
        this.props.loadProducts();
    }
}

function mapStateToProps(storeState, ownProps) {
    return {
        products: storeState.productReducer.products
    };
}

function mapDispatchToProps(dispatch) {
    return {
        loadProducts: () => { dispatch(productActions.loadProducts()); }
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(ProductsContainer);