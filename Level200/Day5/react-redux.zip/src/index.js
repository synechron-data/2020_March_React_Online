import 'bootstrap/scss/bootstrap.scss';

import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter } from 'react-router-dom';
import 'bootstrap';

import './index.css';
import RootComponent from './components/root/RootComponent';

import { Provider } from 'react-redux';
import configureStore from './store/configureStore';

const appStore = configureStore();
console.log(appStore);

// const appStore = configureStore({counterReducer: 1000});
// console.log(appStore);

ReactDOM.render(<Provider store={appStore}>
    <BrowserRouter>
        <RootComponent />
    </BrowserRouter>
</Provider>, document.getElementById('root'));