import * as actionTypes from './actionTypes';
import productsAPIClient from '../services/product.service';

function loadProductsRequested(msg) {
    return {
        type: actionTypes.LOAD_PRODUCTS_REQUESTED,
        payload: { flag: false, message: msg }
    };
}

function loadProductsSuccess(products, msg) {
    return {
        type: actionTypes.LOAD_PRODUCTS_SUCCESS,
        payload: { flag: true, message: msg, data: products }
    };
}

function loadProductsFailed(msg) {
    return {
        type: actionTypes.LOAD_PRODUCTS_FAILED,
        payload: { flag: true, message: msg, data: [] }
    };
}

export function loadProducts() {
    return function (dispatch) {
        dispatch(loadProductsRequested("Load Products, Request Started..."));

        productsAPIClient.getAllProducts().then((products) => {
            dispatch(loadProductsSuccess(products, "Load Products, Request Completed..."));
        }, (eMsg) => {
            dispatch(loadProductsFailed(eMsg));
        });
    };
}