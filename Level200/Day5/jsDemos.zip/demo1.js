const EmployeeFn = (function () {
    function Employee(name) {
        this._name = name;
    }

    Employee.prototype.getName = function () {
        return this._name;
    }

    Employee.prototype.setName = function (name) {
        this._name = name;
    }

    return Employee;
})();

// var e1 = new EmployeeFn("Manish");
// console.log(e1.getName());
// e1.setName("Abhijeet");
// console.log(e1.getName());
