const url = "https://restcountries.eu/rest/v2/all";

const countryAPIClient = {
    getAllCountries: function () {
        var promise = new Promise((resolve, reject) => {
            let fData = {
                method: "GET",
                headers: {
                    "accept": "application/json",
                }
            };

            fetch(url, fData).then((response) => {
                response.json().then((data) => {
                    resolve(data);
                }).catch((err) => {
                    reject("Parsing Error");
                })
            }).catch((err) => {
                reject("Communication Error");
            });
        });

        return promise;
    }
}

export default countryAPIClient;