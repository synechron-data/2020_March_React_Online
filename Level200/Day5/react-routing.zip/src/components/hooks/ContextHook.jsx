import React, { useContext } from 'react';

const dataContext = React.createContext([10, 20, 30, 40, 50]);

const ContextHook = () => {
    const myContext = useContext(dataContext);
    console.log(myContext);

    const handleClick = () => {

    };

    return (
        <div>
            <input type="text" />
            <button onClick={handleClick}>Click</button>
        </div>
    );
};

export default ContextHook;