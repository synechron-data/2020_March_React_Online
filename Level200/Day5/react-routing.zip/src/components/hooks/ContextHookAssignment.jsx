import React, { useContext } from 'react';

const themes = {
    light: {
        foreground: "#000000",
        background: "#eeeeee"
    },
    dark: {
        foreground: "#ffffff",
        background: "#222222"
    }
};

const ThemeContext = React.createContext(themes.light);
console.log(ThemeContext);

const ContextHookAssignment = () => {
    return (
        <ThemeContext.Provider value={themes.dark}>
            <Toolbar />
        </ThemeContext.Provider>
    );
};

const Toolbar = () => {
    return (
        <div>
            <Button />
        </div>
    );
}

const Button = () => {
    const value = useContext(ThemeContext);
    return (
        <button style={{ background: value.background, color: value.foreground }}>
            Click Me
        </button>
    );
}

// const Button = () => {
//     return (
//         <ThemeContext.Consumer>
//             {(value) => (
//                 <button style={{ background: value.background, color: value.foreground }}>
//                     Click Me
//                 </button>
//             )}
//         </ThemeContext.Consumer>
//     );
// }

export default ContextHookAssignment;