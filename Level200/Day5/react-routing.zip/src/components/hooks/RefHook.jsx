import React, { useRef } from 'react';

const RefHook = () => {
    const inpRef = useRef(null);

    const handleClick = () => {
        inpRef.current.focus();
        // console.log(inpRef);
    };

    return (
        <div>
            <input type="text" ref={inpRef} />
            <button onClick={handleClick}>Click</button>
        </div>
    );
};

export default RefHook;