import React, { useState, useEffect } from 'react';
import countryAPIClient from '../../services/country.service';

const EffectAssignment = () => {
    const [countries, setCountries] = useState([]);
    const [load, setLoad] = useState(false);
    const [error, setError] = useState('');

    useEffect(() => {
        countryAPIClient.getAllCountries().then((data) => {
            setCountries(data);
            setLoad(true);
        }, (eMsg) => {
            setError(eMsg);
            setLoad(true);
        })
    }, []);

    if (load) {
        return (
            <ul>
                {
                    error ?
                        <li className="list-group-item list-group-item-danger">{error}</li> :
                        countries.map((country, index) => <li className="list-group-item" key={index}>{country.name}</li>)
                }
            </ul>
        );
    } else {
        return (
            <div>
                Loading......
            </div>
        );
    }
};

export default EffectAssignment;