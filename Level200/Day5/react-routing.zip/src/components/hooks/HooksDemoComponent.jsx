/* eslint-disable */
import React from 'react';
import StateHook from './StateHook';
import WithoutStateHook from './WithoutStateHook';
import EffectHook from './EffectHook';
import EffectAssignment from './EffectAssignment';
import RefHook from './RefHook';
import ContextHook from './ContextHook';
import ContextHookAssignment from './ContextHookAssignment';

const HooksDemoComponent = () => {
    return (
        <div>
            {/* <WithoutStateHook />
            <StateHook /> */}
            {/* <EffectHook /> */}
            {/* <EffectAssignment /> */}
            {/* <RefHook /> */}
            {/* <ContextHook /> */}
            <ContextHookAssignment />
        </div>
    );
};

export default HooksDemoComponent;