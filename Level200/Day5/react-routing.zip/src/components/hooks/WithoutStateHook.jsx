import React, { Component } from 'react';

class WithoutStateHook extends Component {
    constructor(props) {
        super(props);
        this.state = { count: 0 };
    }

    inc(e) {
        this.setState({ count: this.state.count + 1 });
    }

    dec(e) {
        this.setState({ count: this.state.count - 1 });
    }

    render() {
        return (
            <div>
                <h1 className="text-warning">Without State Hook</h1>
                <h2 className="text-info">Count: {this.state.count}</h2>
                <button className="btn btn-primary" onClick={this.inc.bind(this)}>+</button>
                <button className="btn btn-primary" onClick={this.dec.bind(this)}>-</button>
            </div>
        );
    }
}

export default WithoutStateHook;