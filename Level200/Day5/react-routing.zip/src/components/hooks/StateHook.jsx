/* eslint-disable */
import React, { useState } from 'react';

const StateHook = () => {
    const [count, setCount] = useState(0);
    const [message, setMessage] = useState("Hello World");

    return (
        <div>
            <h1 className="text-success">With State Hook</h1>
            <h2 className="text-info">Message: {message}</h2>
            <h2 className="text-info">Count: {count}</h2>
            <button className="btn btn-primary" onClick={() => setCount(count + 1)}>+</button>
            <button className="btn btn-primary" onClick={() => setCount(count - 1)}>-</button>
        </div>
    );
};

export default StateHook;



// const StateHook = () => {

//     // const test = useState(0);
//     // console.log(test[0]);
//     // console.log(test[1]);

//     const [count, setCount] = useState(0);
//     // console.log(count);
//     // console.log(setCount);

//     return (
//         <div>
//             <h1 className="text-success">With State Hook</h1>
//             <h2 className="text-info">Count: {count}</h2>
//             <button className="btn btn-primary" onClick={() => setCount(count + 1)}>+</button>
//             <button className="btn btn-primary" onClick={() => setCount(count - 1)}>-</button>
//         </div>
//     );
// };