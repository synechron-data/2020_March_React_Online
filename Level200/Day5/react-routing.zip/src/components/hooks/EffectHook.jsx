/* eslint-disable */
import React, { useState, useEffect } from 'react';

const EffectHook = () => {
    const [personName, setPersonName] = useState({ fname: 'Manish', lname: 'Sharma' });

    // Without Second Parameter, it behaves like ComponentDidUpdate()

    // With Second Parameter, it behaves like ComponentDidMount()
    useEffect(() => {
        console.log("useEffect is called...");
        setTimeout(function () {
            setPersonName({ fname: 'Abhijeet', lname: 'Gole' });
        }, 5000);
    }, []);

    return (
        <div>
            <h3>Firstname: {personName.fname}</h3>
            <h3>Lastname: {personName.lname}</h3>
        </div>
    );
};

export default EffectHook;