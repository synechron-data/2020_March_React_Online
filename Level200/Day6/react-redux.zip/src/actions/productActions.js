import * as actionTypes from './actionTypes';
import productsAPIClient from '../services/product.service';

import history from '../history';

function loadProductsRequested(msg) {
    return {
        type: actionTypes.LOAD_PRODUCTS_REQUESTED,
        payload: { flag: false, message: msg }
    };
}

function loadProductsSuccess(products, msg) {
    return {
        type: actionTypes.LOAD_PRODUCTS_SUCCESS,
        payload: { flag: true, message: msg, data: products }
    };
}

function loadProductsFailed(msg) {
    return {
        type: actionTypes.LOAD_PRODUCTS_FAILED,
        payload: { flag: true, message: msg, data: [] }
    };
}

export function loadProducts() {
    return function (dispatch) {
        dispatch(loadProductsRequested("Load Products, Request Started..."));

        productsAPIClient.getAllProducts().then((products) => {
            setTimeout(function () {
                dispatch(loadProductsSuccess(products, "Load Products, Request Completed..."));
            }, 500);
        }, (eMsg) => {
            dispatch(loadProductsFailed(eMsg));
        });
    };
}

function insertProductSuccess(insertedProduct, msg) {
    return {
        type: actionTypes.INSERT_PRODUCT_SUCCESS,
        payload: { flag: true, message: msg, data: insertedProduct }
    };
}

export function insertProduct(productToInsert) {
    return function (dispatch) {
        productsAPIClient.insertProduct(productToInsert).then((insertedProduct) => {
            dispatch(insertProductSuccess(insertedProduct, "Insert Success..."));
            history.push('/products');
        }, (eMsg) => {
            console.log(eMsg);
        });
    };
}

function updateProductSuccess(updatedProduct, msg) {
    return {
        type: actionTypes.UPDATE_PRODUCT_SUCCESS,
        payload: { flag: true, message: msg, data: updatedProduct }
    };
}

export function updateProduct(productToUpdate) {
    return function (dispatch) {
        productsAPIClient.updateProduct(productToUpdate).then((updatedProduct) => {
            dispatch(updateProductSuccess(updatedProduct, "Edit Success..."));
            history.push('/products');
        }, (eMsg) => {
            console.log(eMsg);
        });
    };
}

function deleteProductSuccess(deletedProduct, msg) {
    return {
        type: actionTypes.DELETE_PRODUCT_SUCCESS,
        payload: { flag: true, message: msg, data: deletedProduct }
    };
}

export function deleteProduct(productToDelete) {
    return function (dispatch) {
        productsAPIClient.deleteProduct(productToDelete).then(() => {
            dispatch(deleteProductSuccess(productToDelete, "Delete Success..."));
        }, (eMsg) => {
            console.log(eMsg);
        });
    };
}
